# Run Guide

## 1. Create and activate a virtual environment

Windows PowerShell:
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
```

## 2. Install dependencies

```powershell
python -m pip install -r requirements.txt
```

## 3. Run unit tests

```powershell
python -m unittest -v
```

## 4. Run Flask

```powershell
python server.py
```

Open:
http://127.0.0.1:5000/

## 5. Run static analysis

```powershell
python -m pylint server.py
```

Use the actual output from your machine when documenting your work.
