"""Flask web server for the Emotion Detector."""

from flask import Flask, request, render_template_string
from EmotionDetection.emotion_detection import emotion_detector

app = Flask(__name__)

HTML = """
<!doctype html>
<html>
<head>
    <title>Emotion Detector</title>
</head>
<body>
    <h1>Emotion Detector</h1>
    <form method="post">
        <input name="text" placeholder="Enter text" style="width:400px;">
        <button type="submit">Detect Emotion</button>
    </form>
    {% if error %}
        <p>{{ error }}</p>
    {% endif %}
    {% if result %}
        <pre>{{ result }}</pre>
    {% endif %}
</body>
</html>
"""


@app.route("/", methods=["GET", "POST"])
def home():
    """Render the UI and process submitted text."""
    if request.method == "POST":
        text = request.form.get("text", "").strip()

        if not text:
            return render_template_string(
                HTML,
                error="Please enter some text.",
                result=None,
            )

        result = emotion_detector(text)

        if result["dominant_emotion"] is None:
            return render_template_string(
                HTML,
                error="Emotion detection failed for this input.",
                result=None,
            )

        return render_template_string(
            HTML,
            error=None,
            result=result,
        )

    return render_template_string(HTML, error=None, result=None)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
