"""Emotion detection using IBM Watson NLP."""

import requests

WATSON_URL = (
    "https://sn-watson-emotion.labs.skills.network/"
    "v1/watson.runtime.nlp.v1/NlpService/EmotionPredict"
)


def emotion_detector(text_to_analyze):
    """Return emotion scores and dominant emotion for supplied text.

    This implementation is intentionally explicit so the HTTP status
    handling can be tested locally.
    """
    if not text_to_analyze or not text_to_analyze.strip():
        return {
            "anger": None,
            "disgust": None,
            "fear": None,
            "joy": None,
            "sadness": None,
            "dominant_emotion": None,
        }

    payload = {
        "raw_document": {
            "text": text_to_analyze
        }
    }

    try:
        response = requests.post(WATSON_URL, json=payload, timeout=30)
    except requests.RequestException as exc:
        raise RuntimeError("Unable to contact Watson NLP service.") from exc

    if response.status_code == 400:
        return {
            "anger": None,
            "disgust": None,
            "fear": None,
            "joy": None,
            "sadness": None,
            "dominant_emotion": None,
        }

    response.raise_for_status()
    data = response.json()

    emotions = data["emotionPredictions"][0]["emotion"]
    dominant = max(emotions, key=emotions.get)

    return {
        "anger": emotions.get("anger"),
        "disgust": emotions.get("disgust"),
        "fear": emotions.get("fear"),
        "joy": emotions.get("joy"),
        "sadness": emotions.get("sadness"),
        "dominant_emotion": dominant,
    }
